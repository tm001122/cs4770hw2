--==<< Usage >>==--

./encrypt <-d> <key> 
  - '-d' is optional for debugging
  - key should be entered as 0xYYY hexidecimal number

'make'
  - compiles source code into executable called 'encrypt'

'make clean'
  - removes encrypt and encrypt.o files made during compilation